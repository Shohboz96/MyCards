package com.example.examen.data


data class ContactUserData(
    val phoneNumber:String,
    val password:String,
    val lastName:String,
    val firstName:String
)