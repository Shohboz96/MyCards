package com.example.examen.data

data class AddCardData(
    val pan:String,
    val expiredAt:String,
    val name:String,
    val color:Int
)