package com.example.examen.data

data class IntoData(
    val textTop:String,
    val textBottom:String,
    val contentColor:Int
)