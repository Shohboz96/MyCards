package com.example.examen.utils

typealias SingleBlock <T> = (T) -> Unit