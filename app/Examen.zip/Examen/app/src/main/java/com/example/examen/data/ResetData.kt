package com.example.examen.data

data class ResetData(
    val  phoneNumber:String
)