package com.example.examen.data

data class VerifyCardData(
    val pan:String,
    val code:String
)