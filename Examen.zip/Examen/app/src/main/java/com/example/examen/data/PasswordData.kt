package com.example.examen.data

data class PasswordData(
    val phoneNumber:String,
    val password:String,
    val code:String
)