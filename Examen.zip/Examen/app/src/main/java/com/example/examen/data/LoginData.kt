package com.example.examen.data

data class LoginData(
     val phoneNumber:String,
     val  password:String
)

