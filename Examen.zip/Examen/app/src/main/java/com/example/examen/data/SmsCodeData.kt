package com.example.examen.data

data class SmsCodeData(
    val phoneNumber:String,
    val code:String
)