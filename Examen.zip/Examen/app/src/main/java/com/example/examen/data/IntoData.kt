package com.example.examen.data

data class IntoData(
    val textTop:String,
    val imageUrl:Int
)